package app.witwork.vpn.presentation.servers.tab

import app.witwork.vpn.common.base.BaseView

interface TabView : BaseView {
    fun onLoadDataSuccess(index: Int)
}
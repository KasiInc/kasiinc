package app.witwork.vpn.presentation.other.policy

import app.witwork.vpn.common.base.BasePresenter
import javax.inject.Inject

class PrivatePolicyPresenter @Inject constructor() : BasePresenter<PrivatePolicyView>() {
}
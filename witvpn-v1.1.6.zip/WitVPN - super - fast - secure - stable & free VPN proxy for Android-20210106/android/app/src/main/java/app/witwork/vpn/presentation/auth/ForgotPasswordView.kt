package app.witwork.vpn.presentation.auth

import app.witwork.vpn.common.base.BaseView

interface ForgotPasswordView : BaseView {
    fun onForgotPasswordSuccess()
}
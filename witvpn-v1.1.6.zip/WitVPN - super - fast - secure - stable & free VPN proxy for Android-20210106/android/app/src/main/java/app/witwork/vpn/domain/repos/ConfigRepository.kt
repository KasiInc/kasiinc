package app.witwork.vpn.domain.repos

import app.witwork.vpn.domain.model.AdsConfig
import io.reactivex.Observable

interface ConfigRepository {
    fun getConfig(): Observable<AdsConfig>
}
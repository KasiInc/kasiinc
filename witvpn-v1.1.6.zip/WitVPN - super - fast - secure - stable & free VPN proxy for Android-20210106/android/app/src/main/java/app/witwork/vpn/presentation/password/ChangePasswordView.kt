package app.witwork.vpn.presentation.password

import app.witwork.vpn.common.base.BaseView

interface ChangePasswordView : BaseView {
    fun onChangePasswordSuccess()
}
package app.witwork.vpn.presentation.other.policy

import app.witwork.vpn.R
import app.witwork.vpn.common.base.BaseFragment
import app.witwork.vpn.common.base.BasePresenter
import app.witwork.vpn.common.di.component.AppComponent
import javax.inject.Inject

class PrivatePolicyFragment : BaseFragment<PrivatePolicyView, PrivatePolicyPresenter>(), PrivatePolicyView {

    @Inject
    lateinit var presenter: PrivatePolicyPresenter

    override fun inject(appComponent: AppComponent) {
        appComponent.inject(this)
    }

    override fun presenter(): BasePresenter<PrivatePolicyView>? {
        return presenter
    }

    override fun viewIF(): PrivatePolicyView? {
        return this
    }

    override fun getLayoutRes(): Int {
        return R.layout.fragment_private_policy
    }

    override fun initView() {
    }
}

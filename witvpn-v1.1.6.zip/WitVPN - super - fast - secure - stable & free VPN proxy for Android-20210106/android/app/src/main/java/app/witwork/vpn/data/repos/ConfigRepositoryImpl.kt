package app.witwork.vpn.data.repos

import app.witwork.vpn.common.utils.FirebaseConstant
import app.witwork.vpn.common.utils.rxGet
import app.witwork.vpn.domain.model.AdsConfig
import app.witwork.vpn.domain.repos.ConfigRepository
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import io.reactivex.Observable
import javax.inject.Inject

class ConfigRepositoryImpl @Inject constructor() : ConfigRepository {
    override fun getConfig(): Observable<AdsConfig> {
        return Firebase.firestore
            .collection(FirebaseConstant.CONFIGS)
            .rxGet()
            .map {
                val ads = it.documents.firstOrNull()?.data?.get("ads") as? MutableList<*>
                val map = ads?.firstOrNull() as MutableMap<*, *>
                val google = map["google"] as MutableMap<*, *>
                return@map AdsConfig.fromFirebase(google)
            }
    }
}
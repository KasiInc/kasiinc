package app.witwork.vpn.presentation.main

import app.witwork.vpn.common.base.BaseView
import app.witwork.vpn.domain.model.AdsConfig

interface MainView : BaseView {
    fun onGetConfigsSuccess(adsConfig: AdsConfig?)
}
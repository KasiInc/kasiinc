package app.witwork.vpn.presentation.splash

import app.witwork.vpn.common.base.BaseView

interface SplashView : BaseView {
    fun goToMainScreen()
}
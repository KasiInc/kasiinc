package app.witwork.vpn.domain.repos

import app.witwork.vpn.domain.model.Server
import io.reactivex.Observable

interface ServerRepository {
    fun getServers(): Observable<List<Server>>
}